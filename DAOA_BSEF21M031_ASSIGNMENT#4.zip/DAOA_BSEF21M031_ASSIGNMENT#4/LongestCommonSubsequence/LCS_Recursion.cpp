#include<iostream>
#include<string>
#include<string.h>
using namespace std;
int LCS_Recursion(string str1, string str2, int m, int n)
{
	if (m == 0 || n == 0)
		return 0;
	if (str1[m - 1] == str2[n - 1])
		return 1 + LCS_Recursion(str1, str2, m - 1, n - 1);
	else
		return max(LCS_Recursion(str1, str2, m, n - 1),
			LCS_Recursion(str1, str2, m - 1, n));
}
int main()
{
	string str1, str2;
	cout << "Enter the First String : ";
	getline(cin, str1);
	cout << "Enter the Second String : ";
	getline(cin, str2);
	int m = str1.length();
	int n = str2.length();
	cout << "The Longest Common Subsequence is : " << LCS_Recursion(str1, str2,m, n);
}