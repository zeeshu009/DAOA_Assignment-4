#include <iostream>
#include <string>
#include <string.h>
#include <vector>
using namespace std;
// i used top down apporach for sloving longes subsequence problem
int LCS_DP(string str1, string str2, int m, int n, vector<vector<int>> &dp)
{
	if (m == 0 || n == 0)
		return 0;
	if (str1[m - 1] == str2[n - 1])
		return dp[m][n] = 1 + LCS_DP(str1, str2, m - 1, n - 1, dp);
	// if already store result then no need to check
	if (dp[m][n] != -1)
	{
		return dp[m][n];
	}
	return dp[m][n] = max(LCS_DP(str1, str2, m, n - 1, dp),
						  LCS_DP(str1, str2, m - 1, n, dp));
}
int main()
{
	string str1, str2;
	cout << "Enter the First String : ";
	getline(cin, str1);
	cout << "Enter the Second String : ";
	getline(cin, str2);
	int m = str1.length();
	int n = str2.length();
	vector<vector<int>> dp(m + 1, vector<int>(n + 1, -1));
	cout << "The Longest Common Subsequence is : " << LCS_DP(str1, str2, m, n, dp);
}