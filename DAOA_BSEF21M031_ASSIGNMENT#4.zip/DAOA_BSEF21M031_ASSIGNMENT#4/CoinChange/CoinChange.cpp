#include <iostream>
#include <vector>
#include <algorithm>
#include <fstream>
#include <unordered_set>
using namespace std;
// dynamic approach for coin change problem
int Coin_Change_DP(vector<int> &dominations, int coins, int sum)
{
	vector<int> res(sum + 1, INT_MAX);
	res[0] = 0;
	for (int i = 1; i <= sum; i++)
	{
		for (int j = 0; j < coins; j++)
			if (dominations[j] <= i)
			{
				int ans = res[i - dominations[j]];
				if (ans != INT_MAX && ans + 1 < res[i])
					res[i] = ans + 1;
			}
	}
	if (res[sum] == INT_MAX)
		return -1;
	return res[sum];
}
// functions for checking valid dominations
bool areDenominationsValid(const unordered_set<int> &validDenominations, const vector<pair<string, int>> &denominations)
{
	for (const auto &denom : denominations)
	{
		if (validDenominations.find(denom.second) == validDenominations.end())
		{
			return false;
		}
	}
	return true;
}
int main()
{
	ifstream myfile;
	myfile.open("coins.txt");
	if (myfile)
	{
		string country, carency;
		int N;
		myfile >> country >> carency >> N;
		// Define a set of valid denominations for the  Pak Country only
		unordered_set<int> validDenominations = {1, 2, 5, 10, 20, 50, 100};
		vector<pair<string, int>> denominations(N);
		for (int i = 0; i < N; ++i)
		{
			myfile >> denominations[i].first >> denominations[i].second;
		}
		vector<int> domination(N);
		for (int i = 0; i < N; i++)
		{
			domination[i] = denominations[i].second;
		}
		int cnt = 0;
		bool flag = false; // for invalid sum
		// Check if the provided denominations are valid for Pak country
		// if not run dynamic problem
		// for given input file currency are valid
		// i.e values in file are 2 5 10 100
		if (!areDenominationsValid(validDenominations, denominations))
		{
			cout << "Due to invalid Currency greedy Algorithm not worked on given dominations : " << endl;
			int tar;
			cout << "Enter the target Amount to Run Dp on it : ";
			cin >> tar;
			cnt = Coin_Change_DP(domination, N, tar);
		}
		else
		{
			int tar;
			cout << "Enter the target Amount : ";
			cin >> tar;
			sort(domination.begin(), domination.end(), greater<int>());
			for (int i = 0; i < N; i++)
			{
				while (tar >= domination[i])
				{
					flag = true;
					tar -= domination[i];
					cnt++;
				}
			}
		}
		if (cnt != -1 && flag)
			cout << "Total Minimum Count is : " << cnt << endl;
		else
			cout << "Invalid Sum ";
	}
	else
		cout << "Error in file Opening ";
}